=== Gafreax Authorized User Only ===
Contributors: gafreax
Tags: user, authentication
Requires at least: 4.0
Tested up to: 4.0
License: gplv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Really simple plugin for allow only auth user to be logged in

== Installation ==
simple download plugin and activate it

== Changelog ==
1.0 First version
